import { GlobalStyles } from "./styles/GlobalStyles";

export function App() {
  return (
    <>
        <GlobalStyles />
        <h1>Hello world</h1>
    </>
  );
}
